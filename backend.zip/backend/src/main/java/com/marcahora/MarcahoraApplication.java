package com.marcahora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarcahoraApplication {

    public static void main(String[] args) {
        SpringApplication.run(MarcahoraApplication.class, args);
    }
}
